/* Configuration for GCC for Intel i386 running BSDI's BSD/386 as host.  */

#include "i386/xm-i386.h"
