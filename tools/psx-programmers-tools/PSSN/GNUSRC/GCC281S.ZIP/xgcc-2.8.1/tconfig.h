#ifdef SNPSX
#include "mips/xm-psx.h"
#endif
#ifdef SNN64
#include "mips/xm-n64.h"
#endif
#ifdef SNARM
#include "arm/xm-arm.h"
#endif
#ifdef SNPHX
#include "mips/xm-phoenix.h"
#endif
