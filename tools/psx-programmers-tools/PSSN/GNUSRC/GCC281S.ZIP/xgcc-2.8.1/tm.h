#ifdef SNPSX
#include "mips/psx.h"
#endif
#ifdef SNN64
#include "mips/n64.h"
#endif
#ifdef SNARM
#include "arm/pda.h"
#endif
#ifdef SNPHX
#include "mips/phoenix.h"
#endif
